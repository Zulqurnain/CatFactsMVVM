package com.jutt.catfactsfeeddemo.application

object Contants {
    const val SERVER_DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
    const val FRIENDLY_DATE_TIME_FORMAT = "dd MMM yyyy hh:mm a"
}